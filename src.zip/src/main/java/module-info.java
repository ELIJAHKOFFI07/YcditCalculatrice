module koffiamonnindanielelie.diahouyapocharlesemmanuel.ycditcalculatrice {
    requires javafx.controls;
    requires javafx.fxml;


    opens koffiamonnindanielelie.diahouyapocharlesemmanuel.ycditcalculatrice to javafx.fxml;
    exports koffiamonnindanielelie.diahouyapocharlesemmanuel.ycditcalculatrice;
}